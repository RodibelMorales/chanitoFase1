<?php
$confi= null;
$confi= array();
$confi['server'] = 'localhost:8080';
$confi['usuario'] = 'root';
$confi['clave'] = '';
$confi['basedato'] = 'transinet';

?>