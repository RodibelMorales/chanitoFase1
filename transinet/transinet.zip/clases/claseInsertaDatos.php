<?php 
//class insertar{
//	
//	function GeneraMulta(){
//		$newMulta = mysql_query("INSERT INTO ");
//	}
//}



?>