<?php 

//include ('config.php');
include ('conexion.php');
include ('clasesSesiones.php');
include ('busquedas.php');
include ('claseinsertaDatos.php');
include ('clasesBusquedaArticulos.php');
?>