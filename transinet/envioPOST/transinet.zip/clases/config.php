<?php
$confi= null;
$confi= array();
$confi['server'] = 'localhost';
$confi['usuario'] = 'root';
$confi['clave'] = 'Pctecno01';
$confi['basedato'] = 'transinet';

?>