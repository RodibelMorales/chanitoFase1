<?php
include('../clases/motorClases.php');
$cerrarSesion = new Sesiones();
$cerrarSesion->CloseSesion();
?>