<?php
include ('../clases/motorClases.php');
$nuevaSesion = new Sesiones();
	$nuevaSesion->usuario  = $_POST['user'];
	$nuevaSesion->password = $_POST['password'];
	$nuevaSesion->StarSesion();
?>